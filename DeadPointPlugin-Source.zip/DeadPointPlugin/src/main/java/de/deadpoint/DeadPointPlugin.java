package de.deadpoint;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class DeadPointPlugin extends JavaPlugin implements Listener {

    private static final int MAX = 10; // gespeicherte Todespunkte pro Spieler
    private final Map<UUID, LinkedList<String>> deaths = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();
    private File file;

    @Override
    public void onEnable() {
        file = new File(getDataFolder(), "deaths.yml");
        if (file.exists()) {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
            for (String key : y.getKeys(false)) {
                UUID id = UUID.fromString(key);
                names.put(id, y.getString(key + ".name", "?"));
                deaths.put(id, new LinkedList<>(y.getStringList(key + ".list")));
            }
        }
        getServer().getPluginManager().registerEvents(this, this);
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, LinkedList<String>> e : deaths.entrySet()) {
            y.set(e.getKey() + ".name", names.get(e.getKey()));
            y.set(e.getKey() + ".list", new ArrayList<>(e.getValue()));
        }
        try {
            getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ex) {
            getLogger().warning("Speichern fehlgeschlagen: " + ex.getMessage());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        Location l = p.getLocation();
        LinkedList<String> list = deaths.computeIfAbsent(p.getUniqueId(), k -> new LinkedList<>());
        list.addFirst(l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ()
                + ";" + l.getYaw() + ";" + l.getPitch());
        while (list.size() > MAX) list.removeLast();
        names.put(p.getUniqueId(), p.getName());
        save();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player admin) || !sender.hasPermission("deadpoint.use")) {
            sender.sendMessage("Keine Berechtigung.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage("Benutzung: /deadpoint <spieler> [nummer]  (1 = letzter Tod)");
            return true;
        }
        int n = 1;
        if (args.length >= 2) {
            try {
                n = Integer.parseInt(args[1]);
            } catch (NumberFormatException ex) {
                sender.sendMessage("Die Nummer muss eine Zahl sein.");
                return true;
            }
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        List<String> list = deaths.get(target.getUniqueId());
        if (list == null || list.isEmpty()) {
            sender.sendMessage("Keine Todespunkte fuer " + args[0] + " gespeichert.");
            return true;
        }
        if (n < 1 || n > list.size()) {
            sender.sendMessage(args[0] + " hat nur " + list.size() + " gespeicherte Todespunkte.");
            return true;
        }
        String[] s = list.get(n - 1).split(";");
        World w = Bukkit.getWorld(s[0]);
        if (w == null) {
            sender.sendMessage("Die Welt " + s[0] + " ist nicht geladen.");
            return true;
        }
        Location loc = new Location(w, Double.parseDouble(s[1]), Double.parseDouble(s[2]),
                Double.parseDouble(s[3]), Float.parseFloat(s[4]), Float.parseFloat(s[5]));
        final int number = n;
        admin.teleportAsync(loc).thenAccept(ok -> admin.sendMessage(ok
                ? "Teleportiert zu Todespunkt " + number + " von " + args[0] + " ("
                + loc.getBlockX() + " " + loc.getBlockY() + " " + loc.getBlockZ() + ")"
                : "Teleport fehlgeschlagen."));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("deadpoint.use")) return out;
        if (args.length == 1) {
            out.addAll(names.values());
        } else if (args.length == 2) {
            for (int i = 1; i <= MAX; i++) out.add(String.valueOf(i));
        }
        String last = args[args.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(last));
        return out;
    }
}
